#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main (void){
    string worldname = "CptS223";
    cout << "Hello " << worldname << "!"<< endl;
    cout << "anthony" << endl;
    return 0;
}