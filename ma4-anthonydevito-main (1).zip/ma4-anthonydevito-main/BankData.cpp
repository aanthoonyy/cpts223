// #include "BankData.hpp"

// int BankData::getAcctNum() const
// {
// 	return *(this->mpAcctNum);
// }

// double BankData::getSavingsAmount() const
// {
// 	return *(this->mpSavingsAmount);
// }

// double BankData::getCheckingAmount() const
// {
// 	return *(this->mpCheckingAmount);
// }

// void BankData::setAcctNum(const int& newAcctNum)
// {
// 	// you need to implement
// }

// void BankData::setSavingsAmount(const double& newSavingsAmount)
// {
// 	// you need to implement
// }

// void BankData::setCheckingAmount(const double& newCheckingAmount)
// {
// 	// you need to implement
// }