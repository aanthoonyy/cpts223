#include <iostream>
#include "functions.h"

using std::cout;
using std::endl;

void printMessage (void)
{
   cout << "We are learning to use make and Makefiles!" << endl;
}