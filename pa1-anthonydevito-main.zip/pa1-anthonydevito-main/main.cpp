
#include "functions.h"
#include "linkedList.hpp"
#include "menu.hpp"
// this was in main already idk what it is
  //printMessage();
   //cout << "The factorial of 6 is " << recFactorial(6) << endl;
int main()
{
    
  Menu m;
  m.runapp();

  return 0;
}