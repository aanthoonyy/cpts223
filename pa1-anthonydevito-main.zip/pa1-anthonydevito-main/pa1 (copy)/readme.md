i was experiencing a "segmation error" randomly every once in a while.

i can't replicate it and it all looks fine to me.

i haven't done anything to fix it, but i havent seen it in my final testing

so i might have fixed it

if for whatever reason you come accross it can you leave a comment on canvas
