void printMessage(void);
int recFactorial(int n);