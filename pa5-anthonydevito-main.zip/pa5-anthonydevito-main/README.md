only works when you make prog in command line. the run button doesnt work
