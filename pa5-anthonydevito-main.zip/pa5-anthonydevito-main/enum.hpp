#pragma once
enum EntryState {
    EMPTY = 0,
    VALID = 1,
    DELETED = 2
};
